package arquiteturaii;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;


public class ArquiteturaII {

    //variaveis de registradores globais
    static String $R1 = "";
    static String $R2 = "";
    static String $R3 = "";
    static int stop = 0;

    public static void main(String[] args) throws IOException {

        //leitura do arquivo
        InputStream is = new FileInputStream("arquitetura.txt");
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(isr);

        int[] instru = new int[32];//vetor da instrução sendo executada
        int pc = 0;                  //registrador do ponit counter
        int Apc = 0;                 //valor do point counter anterior
        int indice;                //indice do da posição do vetor de instuções
        for (;;) {
            indice = 0;
            while (pc < Apc + 32) //preenche o vetor com a instrução
            {
                instru[indice] = br.read();
                if (instru[indice] == -1) //se o arquivo termina ele para a leitura
                {
                    break;
                }
                System.out.print((char) instru[indice]);
                pc++;
                indice++;
            }

            if (pc - Apc == 32) //verifica se a instrução está completa
            {
                verifica(instru);
                System.out.println("\n"+$R1);
                Apc = pc;
                if (stop == 1) {
                    System.out.println("\nErro de memória: valor buscado inexistente!!");
                    break;
                }
                if (stop == 2) {
                    System.out.println("\nErro de memória: memória cheia!!");
                    break;
                }

            } else {
                if (pc - Apc != 0) {
                    System.out.println("\nInstrução incompleta corrija o arquivo!!");
                }
                break;
            }
        }
    }

    public static int[] escolheReg(int[] instru, int numberReg) {
        int[] num = new int[3];
        String regI1 = "";
        String regI2 = "";
        String regI3 = "";

        for (int i = 0; i <= 32; i++) {
            if (i <= 10 && i > 5) {
                regI3 = regI3 + "" + (char) instru[i];
            }
            if (i <= 15 && i > 10 && (numberReg == 2 || numberReg == 3)) {
                regI1 = regI1 + "" + (char) instru[i];
            }
            if (i <= 20 && i > 15 && numberReg == 3) {
                regI2 = regI2 + "" + (char) instru[i];
            }
        }

        if (!regI1.equals("")) {
            switch (regI1) {
                case "00001": {
                    num[0] = 1;
                    break;
                }
                case "00010": {
                    num[0] = 2;
                    break;
                }
                case "00011": {
                    num[0] = 3;
                    break;
                }
                default: {
                    num[0] = 0;
                    break;
                }
            }
        }
        if (!regI2.equals("")) {
            switch (regI2) {
                case "00001": {
                    num[1] = 1;
                    break;
                }
                case "00010": {
                    num[1] = 2;
                    break;
                }
                case "00011": {
                    num[1] = 3;
                    break;
                }
                default: {
                    num[1] = 0;
                    break;
                }
            }
        }
        switch (regI3) {
            case "00001": {
                num[2] = 1;
                break;
            }
            case "00010": {
                num[2] = 2;
                break;
            }
            case "00011": {
                num[2] = 3;
                break;
            }
            default: {
                num[2] = 0;
                break;
            }
        }

        return num;
    }

    public static int buscachash(int[] instru) throws FileNotFoundException, IOException {
        InputStream ischash = new FileInputStream("cash.txt");
        InputStreamReader isrcash = new InputStreamReader(ischash);
        BufferedReader brcash = new BufferedReader(isrcash);

        String[] linecash = new String[11];
        String linha;
        String tag;
        String indice;
        String posi;
        boolean miss = true;
        for (int i = 0; i < 11; i++) {
            linecash[i] = "";
        }

        while ((linha = brcash.readLine()) != null) {

            String[] separar = linha.split(" ");
            System.arraycopy(separar, 0, linecash, 0, separar.length);

            tag = "" + (char) instru[12];
            indice = "" + (char) instru[13] + "" + (char) instru[14];
            posi = "" + (char) instru[15] + "" + (char) instru[16];

            if (linecash[1].equals(indice)) {
                
                if (linecash[2].equals("")) {
                    miss = true;
                } else {
                    
                    if (linecash[2].equals(tag)) {
                        
                        int[] num = escolheReg(instru, 1);
                        if (posi.equals("00") && !linecash[4].equals("") && linecash[0].equals("1")) {
                            System.out.println("opa!!!");
                            switch (num[2]) {
                                case 1: {
                                    $R1 = tag + "" + indice + "" + posi;
                                    break;
                                }
                                case 2: {
                                    $R2 = tag + "" + indice + "" + posi;
                                    break;
                                }
                                default: {
                                    $R3 = tag + "" + indice + "" + posi;
                                    break;
                                }
                            }
                            miss = false;
                            break;
                        } else if (posi.equals("01") && !linecash[6].equals("") && linecash[0].equals("1")) {
                            switch (num[2]) {
                                case 1: {
                                    $R1 = tag + "" + indice + "" + posi;
                                    break;
                                }
                                case 2: {
                                    $R2 = tag + "" + indice + "" + posi;
                                    break;
                                }
                                default: {
                                    $R3 = tag + "" + indice + "" + posi;
                                    break;
                                }
                            }
                            miss = false;
                            break;
                        } else if (posi.equals("10") && !linecash[8].equals("") && linecash[0].equals("1")) {
                            switch (num[2]) {
                                case 1: {
                                    $R1 = tag + "" + indice + "" + posi;
                                    break;
                                }
                                case 2: {
                                    $R2 = tag + "" + indice + "" + posi;
                                    break;
                                }
                                default: {
                                    $R3 = tag + "" + indice + "" + posi;
                                    break;
                                }
                            }
                            miss = false;
                            break;
                        } else if (posi.equals("11") && !linecash[10].equals("") && linecash[0].equals("1")) {
                            switch (num[2]) {
                                case 1: {
                                    $R1 = tag + "" + indice + "" + posi;
                                    break;
                                }
                                case 2: {
                                    $R2 = tag + "" + indice + "" + posi;
                                    break;
                                }
                                default: {
                                    $R3 = tag + "" + indice + "" + posi;
                                    break;
                                }
                            }
                            miss = false;
                            break;
                        }
                    }
                }
            }
        }
        if (miss) {
            return 0;
        } else {
            return 1;
        }
    }

    
    public static void salvaCash(String saveCash) throws FileNotFoundException, IOException
    {
        InputStream ismem = new FileInputStream("memoria.txt");
        InputStreamReader isrmem = new InputStreamReader(ismem);
        BufferedReader brmem = new BufferedReader(isrmem);
        
        InputStream ischash = new FileInputStream("cash.txt");
        InputStreamReader isrcash = new InputStreamReader(ischash);
        BufferedReader brcash = new BufferedReader(isrcash);
        
        OutputStream oscash = new FileOutputStream("cash.txt");
        OutputStreamWriter oswcash = new OutputStreamWriter(oscash);
        BufferedWriter bwcash = new BufferedWriter(oswcash);
        
        ArrayList<String> arquivo = new ArrayList<>();
        
        String[] store = new String[2];
        String[] storeNum = new String[2];
        String[] lineMem = new String[2];
        String[] linhaCash = new String[11];
        String[] lineNum = new String[5];
        
        String linha;
        String percorreCash;
        String tag;
        String indice;
        String posi;
        while ((linha = brmem.readLine()) != null)
        {
            store[0] = "";
            store[1] = "";
            String[] separar = linha.split(" ");
            String[] separarNum = store[1].split("");
            System.arraycopy(separar, 0, lineMem, 0, separar.length);
            System.arraycopy(separarNum, 0, lineNum, 0, separar.length);
            if(store[0].equals(saveCash))
            {
                tag = "" + lineNum[0];
                indice = "" +lineNum[1] + "" + lineNum[2];
                posi = "" + lineNum[3] + "" + lineNum[4];
                System.out.println("opa achei!!");
                
                while ((percorreCash = brcash.readLine()) != null) 
                {
                    arquivo.add(linha);
                }
                arquivo.add("");
                brcash.close();
                
                for (int k = 0; k < arquivo.size() - 1; k++)
                {
                    String[] separarCash = arquivo.get(k).split(" ");
                    System.arraycopy(separarCash, 0, linhaCash, 0, separar.length);
                    
                    if(linhaCash[1].equals(indice))
                    {
                        linhaCash[2]=tag;
                        switch (posi) {
                            case "00":
                                linhaCash[4]= store[1];
                                break;
                            case "01":
                                linhaCash[6]= store[1];
                                break;
                            case "10":      
                                linhaCash[8]= store[1];
                                break;
                            case "11":
                                linhaCash[10]= store[1];
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
            //FAZER COM QUE GRAVE OS 3 VALORES SEGUINTES DA MEMÓRIA
            //REESCREVER ARQUIVO
        }   
    }
    
    public static void verifica(int[] instru) throws IOException {
        String func = "";
        stop = 0;
        for (int i = 0; i < 6; i++) {
            func = func + "" + (char) instru[i];//retira da instrução inteira hapenas os bits de verificação de função
        }
        if (func.equals("000000")) //escolhe qual função a ser executada
        //add
        {
            int num1 = 0;
            int num2 = 0;
            int num3 = 0;

            int[] num = escolheReg(instru, 3);
            System.out.println($R1);
            System.out.println($R2);
            switch (num[0]) {
                case 1: {
                    num1 = Integer.parseInt($R1, 2);
                    break;
                }
                case 2: {
                    num1 = Integer.parseInt($R2, 2);
                    break;
                }
                case 3: {
                    num1 = Integer.parseInt($R3, 2);
                    break;
                }
            }
            switch (num[1]) {
                case 1: {
                    num2 = Integer.parseInt($R1, 2);
                    break;
                }
                case 2: {
                    num2 = Integer.parseInt($R2, 2);
                    break;
                }
                case 3: {
                    num2 = Integer.parseInt($R3, 2);
                    break;
                }
            }

            System.out.println(num1);
            System.out.println(num2);

            num3 = num1 + num2;

            System.out.println(num3);
            switch (num[2]) {
                case 1: {
                    $R1 = Integer.toBinaryString(num3);
                    System.out.println($R1);
                    $R2 = "";
                    $R3 = "";
                    break;
                }
                case 2: {
                    $R2 = Integer.toBinaryString(num3);
                    System.out.println($R2);
                    $R1 = "";
                    $R3 = "";
                    break;
                }
                case 3: {
                    $R3 = Integer.toBinaryString(num3);
                    System.out.println($R3);
                    $R1 = "";
                    $R2 = "";
                    break;
                }
            }
        } else if (func.equals("101000")) //store
        {

            System.out.println("1");
            System.out.println($R1);
            System.out.println("2");
            System.out.println($R2);
            System.out.println("3");
            System.out.println($R3);
            
            InputStream ismem = new FileInputStream("memoria.txt");
            InputStreamReader isrmem = new InputStreamReader(ismem);
            BufferedReader brmem = new BufferedReader(isrmem);

            String linha;
            ArrayList<String> arquivo = new ArrayList<>();
            String[] store = new String[2];
            String verific = "" + (char) instru[11];
            String[] separar;
            String linhaAlterada;
            String numero = "";
            int k;
            while ((linha = brmem.readLine()) != null) {
                arquivo.add(linha);
            }
            arquivo.add("");
            brmem.close();

            for (k = 0; k < arquivo.size() - 1; k++) {
                store[0] = "";
                store[1] = "";
                separar = arquivo.get(k).split(" ");
                System.arraycopy(separar, 0, store, 0, separar.length);

                if (verific.equals("0")) {
                    if (store[1].equals("")) {
                        int[] num = escolheReg(instru, 1);
                        switch (num[2]) {
                            case 1: {
                                System.out.println("\n" + $R1);
                                linhaAlterada = store[0] + " " + $R1;
                                break;
                            }
                            case 2: {
                                System.out.println("\n" + $R2);
                                linhaAlterada = store[0] + " " + $R2;
                                break;
                            }
                            default: {
                                System.out.println("\n" + $R3);
                                linhaAlterada = store[0] + " " + $R3;
                                break;
                            }
                        }

                        arquivo.set(k, linhaAlterada);

                        OutputStream os = new FileOutputStream("memoria.txt");
                        OutputStreamWriter osw = new OutputStreamWriter(os);
                        BufferedWriter bw = new BufferedWriter(osw);

                        for (int i = 0; i < arquivo.size() - 1; i++) {
                            bw.write(arquivo.get(i) + "\n");
                        }
                        bw.close();
                        break;
                    }
                } else {
                    numero = "";
                    for (int j = 12; j <= 16; j++) {
                        numero = numero + "" + (char) instru[j];
                    }

                    if (store[0].equals(numero)) {
                        int[] num = escolheReg(instru, 1);
                        switch (num[2]) {
                            case 1: {
                                System.out.println("\n" + $R1);
                                linhaAlterada = store[0] + " " + $R1;
                                break;
                            }
                            case 2: {
                                System.out.println("\n" + $R2);
                                linhaAlterada = store[0] + " " + $R2;
                                break;
                            }
                            default: {
                                System.out.println("\n" + $R3);
                                linhaAlterada = store[0] + " " + $R3;
                                break;
                            }
                        }

                        arquivo.set(k, linhaAlterada);

                        OutputStream os = new FileOutputStream("memoria.txt");
                        OutputStreamWriter osw = new OutputStreamWriter(os);
                        BufferedWriter bw = new BufferedWriter(osw);
                        for (int i = 0; i < arquivo.size() - 1; i++) {
                            bw.write(arquivo.get(i) + "\n");
                        }
                        bw.close();
                        break;
                    } else {
                        stop = 1;
                        break;
                    }
                }
            }
            if (arquivo.get(k).equals("")) {
                stop = 2;
            }
            brmem.close();
        } else if (func.equals("100011")) //load
        {
            InputStream ismem = new FileInputStream("memoria.txt");
            InputStreamReader isrmem = new InputStreamReader(ismem);
            BufferedReader brmem = new BufferedReader(isrmem);
            boolean achou = false;
            String linha;
            String numero;
            String[] store = new String[2];
            int[] num = escolheReg(instru, 1);
            boolean memoria = false;
            String verific = "" + (char) instru[11];
            for (int i = 12; i <= 16; i++) {
                if (verific.equals("0")) {
                    memoria = true;
                }
                if (i <= 16 && !memoria) {
                    switch (num[2]) {
                        case 1: {
                            $R1 = $R1 + "" + (char) instru[i];
                            break;
                        }
                        case 2: {
                            $R2 = $R2 + "" + (char) instru[i];
                            break;
                        }
                        default: {
                            $R3 = $R3 + "" + (char) instru[i];
                            break;
                        }
                    }
                } else {
                    if (buscachash(instru) == 0) {
                        while ((linha = brmem.readLine()) != null) {
                            numero = "";
                            store[0] = "";
                            store[1] = "";
                            String[] separar = linha.split(" ");

                            System.arraycopy(separar, 0, store, 0, separar.length);

                            for (int j = 12; j <= 16; j++) {
                                numero = numero + "" + (char) instru[j];
                            }
                            if (store[1].equals(numero)) {
                                switch (num[2]) {
                                    case 1: {
                                        $R1 = store[1];
                                        achou = true;
                                        break;
                                    }
                                    case 2: {
                                        $R2 = store[1];
                                        achou = true;
                                        break;
                                    }
                                    default: {
                                        $R3 = store[1];
                                        achou = true;
                                        break;
                                    }
                                }
                            }
                            break;
                        }
                    } else {
                        achou = true;
                        break;
                    }
                }
            }
            if (!achou) {
                stop = 1;
            }
            else 
                salvaCash(store[0]);
            
            brmem.close();
        }
    }
}
