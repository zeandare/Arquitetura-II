package arquiteturaii;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class ArquiteturaII {

    //variaveis de registradores globais
    static String $R1 = "";
    static String $R2 = "";
    static String $R3 = "";

    public static void main(String[] args) throws IOException {

        //leitura do arquivo
        InputStream is = new FileInputStream("arquitetura.txt");
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(isr);

        int[] instru = new int[32];//vetor da instrução sendo executada
        int pc = 0;                  //registrador do ponit counter
        int Apc = 0;                 //valor do point counter anterior
        int indice;                //indice do da posição do vetor de instuções
        for (;;) {
            indice = 0;
            while (pc < Apc + 32) //preenche o vetor com a instrução
            {
                instru[indice] = br.read();
                if (instru[indice] == -1) //se o arquivo termina ele para a leitura
                {
                    break;
                }
                System.out.print((char) instru[indice]);
                pc++;
                indice++;
            }

            if (pc - Apc == 32) //verifica se a instrução está completa
            {
                verifica(instru);                           //verifica qual a ação a ser excutada
                Apc = pc;

            } else {
                if (pc - Apc != 0) {
                    System.out.println("Instrução incompleta corrija o arquivo!!");
                }
                break;
            }
        }
    }

    public static int[] escolheReg(int[] instru, int numberReg) {
        int[] num = new int[3];
        String regI1 = "";
        String regI2 = "";
        String regI3 = "";

        for (int i = 0; i <= 32; i++) {
            if (i <= 10 && i > 5) {
                regI3 = regI3 + "" + (char) instru[i];
            }
            if (i <= 15 && i > 10 && (numberReg == 2 || numberReg == 3)) {
                regI1 = regI1 + "" + (char) instru[i];
            }
            if (i <= 20 && i > 15 && numberReg == 3) {
                regI2 = regI2 + "" + (char) instru[i];
            }
        }

        if (!regI1.equals("")) {
            switch (regI1) {
                case "00001": {
                    num[0] = 1;
                    break;
                }
                case "00010": {
                    num[0] = 2;
                    break;
                }
                case "00011": {
                    num[0] = 3;
                    break;
                }
                default: {
                    num[0] = 0;
                    break;
                }
            }
        }
        if (!regI2.equals("")) {
            switch (regI2) {
                case "00001": {
                    num[1] = 1;
                    break;
                }
                case "00010": {
                    num[1] = 2;
                    break;
                }
                case "00011": {
                    num[1] = 3;
                    break;
                }
                default: {
                    num[1] = 0;
                    break;
                }
            }
        }
        switch (regI3) {
            case "00001": {
                num[2] = 1;
                break;
            }
            case "00010": {
                num[2] = 2;
                break;
            }
            case "00011": {
                num[2] = 3;
                break;
            }
            default: {
                num[2] = 0;
                break;
            }
        }

        return num;
    }

    public static void verifica(int[] instru) throws IOException {
        String func = "";

        for (int i = 0; i < 6; i++) {
            func = func + "" + (char) instru[i];//retira da instrução inteira hapenas os bits de verificação de função
        }
        if (func.equals("000000")) //escolhe qual função a ser executada
        //add
        {
            int num1 = 0;
            int num2 = 0;
            int num3 = 0;

            int[] num = escolheReg(instru, 3);
            System.out.println($R1);
            System.out.println($R2);
            switch (num[0]) {
                case 1: {
                    num1 = Integer.parseInt($R1, 2);
                    break;
                }
                case 2: {
                    num1 = Integer.parseInt($R2, 2);
                    break;
                }
                case 3: {
                    num1 = Integer.parseInt($R3, 2);
                    break;
                }
            }
            switch (num[1]) {
                case 1: {
                    num2 = Integer.parseInt($R1, 2);
                    break;
                }
                case 2: {
                    num2 = Integer.parseInt($R2, 2);
                    break;
                }
                case 3: {
                    num2 = Integer.parseInt($R3, 2);
                    break;
                }
            }
            System.out.println(num1);
            System.out.println(num2);

            num3 = num1 + num2;

            System.out.println(num3);
            switch (num[2]) {
                case 1: {
                    $R1 = Integer.toBinaryString(num3);
                    System.out.println($R1);
                    $R2 = "";
                    $R3 = "";
                    break;
                }
                case 2: {
                    $R2 = Integer.toBinaryString(num3);
                    System.out.println($R2);
                    $R1 = "";
                    $R3 = "";
                    break;
                }
                case 3: {
                    $R3 = Integer.toBinaryString(num3);
                    System.out.println($R3);
                    $R1 = "";
                    $R2 = "";
                    break;
                }
            }
        } else if (func.equals("101000")) //store
        {

            OutputStream os = new FileOutputStream("memoria.txt");
            OutputStreamWriter osw = new OutputStreamWriter(os);
            PrintWriter bw = new PrintWriter(osw);
            int[] num = escolheReg(instru, 1);
            System.out.println("");
            switch (num[2]) {
                case 1: {
                    System.out.println("(((((r1((("+$R1+"))))))))");
                    bw.write($R1);
                    break;
                }
                case 2: {
                    System.out.println("((((r2(((("+$R2+"))))))))");
                    bw.write($R2);
                    break;
                }
                default: {
                    System.out.println("(((((r3((("+$R3+"))))))))");
                    bw.println($R3);
                    break;
                }
            }
            bw.close();
        } else if (func.equals("100011")) //load
        {

            int[] num = escolheReg(instru, 1);
            boolean memoria = false;
            for (int i = 0; i <= 16; i++) {
                if(i==11 && instru[i]==0){
                    memoria = true;
                }
                if (i <= 16 && i > 11 && !memoria) {
                    switch (num[2]) {
                        case 1: {
                            $R1 = $R1 + "" + (char) instru[i];
                            break;
                        }
                        case 2: {
                            $R2 = $R2 + "" + (char) instru[i];
                            break;
                        }
                        default: {
                            $R3 = $R3 + "" + (char) instru[i];
                            break;
                        }
                    }
                }else{
                    InputStream ismem = new FileInputStream("memoria.txt");
                    InputStreamReader isrmem = new InputStreamReader(ismem);
                    BufferedReader brmem = new BufferedReader(isrmem);
                    
                    String linha="";
                    String endereco="";
                    int k = 0;
                    String numero = "";
                    linha = brmem.readLine();
                    while(linha!=null){
                        for (int j = 11; j < 16; j++) {
                            numero = numero + "" + (char) instru[i];
                            k++;
                        }
                        for (int j = 0; j < 5; j++) {
                           endereco = endereco +""+
                        }
                        if(linha.equals(numero)){
                            
                        }
                    }
                }
            }
        }
    }
}
